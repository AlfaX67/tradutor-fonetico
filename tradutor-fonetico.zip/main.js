
const app = document.getElementById("root");
app.innerHTML = `
  <h1>Tradutor Fonético</h1>
  <p>Interface de teste para YouTube com legenda fonética + tradução.</p>
  <p>O player real com legendas será incluído na versão final.</p>
`;
